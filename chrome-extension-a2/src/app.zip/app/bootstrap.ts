//import 'zone.js';
//import 'reflect-metadata';

import {bootstrap}    from '@angular/platform-browser-dynamic';
import {AppComponent} from './appComponent';
import {enableProdMode} from '@angular/core';

enableProdMode();

bootstrap(AppComponent);
