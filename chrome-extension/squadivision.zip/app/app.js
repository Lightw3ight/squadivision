angular.module('app', [
	'LocalStorageModule'
]);