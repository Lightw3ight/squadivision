export interface IAppSettings {
	serverUrl?: string;
	lastScreen?: string;
}