angular.module('app', [
	'ui.bootstrap'
]);